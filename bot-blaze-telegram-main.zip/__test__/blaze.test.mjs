import 'dotenv/config';
import { BlazeCore } from '../src/core/blaze.mjs';

let controller = new BlazeCore();

// let socket = controller.start();

// controller.recents().then(console.log)
